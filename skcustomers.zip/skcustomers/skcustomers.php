<?php
/**
*Plugin Name: SK Customers
*Plugin URI: https://sysfore.com/
*Description: Used to manage customers 
*Version: 0.3
*Author: Sathish Kumar
*/

add_action( 'admin_menu', 'sk_customers_menu' );
define( 'WP_DEBUG', true );
/** Step 1. */
function sk_customers_menu() {
	add_menu_page( 'SK Customers Options', 'SK Customers', 'manage_options', 'sk-customer', 'sk_customers_options' );
}



function my_admin_notice() {
    ?>
    <div class="updated">
        <p><?php _e( 'Updated!', 'text-domain' ); ?></p>
    </div>
    <?php
}


if(isset($_GET['action']) && $_GET['action'] == 'delete'){
	global $wpdb;
	$tb_name = $wpdb->prefix . 'skcustomers';
	if(isset($_GET['id']) && $_GET['id'] != ''){
		 $res = $wpdb->delete( $tb_name, array( 'id' => $_GET['id'] ) );
		 if($res){
		 	$loc =  $_SERVER["PHP_SELF"].'?page=sk-customer';
		 	header('location:'.$loc);
		 }
	}
 
}

// run the install scripts upon plugin activation
register_activation_hook(__FILE__,'sk_customers_options_install');

 global $sk_db_version;
$sk_db_version = '1.0';
// function to create the DB / Options / Defaults					
function sk_customers_options_install() {
   	global $wpdb;
  	global $sk_db_version;
        $tb_name = $wpdb->prefix . 'skcustomers';
        $charset_collate = $wpdb->get_charset_collate();
       // print_r($charset_collate);
       // die;
      
	// create the ECPT metabox database table
//	if($wpdb->get_var("show tables like '$tb_name'") != $tb_name) 
	//{
		$sql = "CREATE TABLE $tb_name (
		`id` mediumint(9) NOT NULL AUTO_INCREMENT,
		`name` varchar(100) NOT NULL,
		`address` text NOT NULL,
		`phone` bigint(10) NOT NULL,
		`email` varchar(100) NOT NULL,
        `image` varchar(255) NOT NULL,
        `status` varchar(15) ,
         UNIQUE KEY id (id)
		) $charset_collate;";
 
		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	//}


	   add_option( 'sk_db_version', $sk_db_version );
        $the_page_title = 'Add Customers';
		$the_page_name = 'New Customers';
		// the menu entry...
		add_option("sk_customers_page_title", $the_page_title, '', 'yes');
		// the slug...
		add_option("sk_customers_page_name", $the_page_name, '', 'yes');
		// the id...
		add_option("sk_customers_page_id", '0', '', 'yes');

		$the_page = get_page_by_title( $the_page_title );

		if ( ! $the_page ) {
			// Create post object
			$_p = array();
			$_p['post_title'] = $the_page_title;
			$_p['post_content'] = "[sk_customer_form]";
			$_p['post_status'] = 'publish';
			$_p['post_type'] = 'page';
			$_p['comment_status'] = 'closed';
			$_p['ping_status'] = 'closed';
			$_p['post_category'] = array(1); // the default 'Uncatrgorised'

			// Insert the post into the database
			$the_page_id = wp_insert_post( $_p );
		}
			
		delete_option( 'sk_customers_page_id' );
		add_option( 'sk_customers_page_id', $the_page_id );
		


 
}





register_deactivation_hook( __FILE__, 'sk_customers_deactivate' );

function sk_customers_deactivate(){
	       global $wpdb;
           $tb_name = $wpdb->prefix . 'skcustomers';

		  
		 delete_option('sk_db_version');
		  $wpdb->query("DROP TABLE IF EXISTS $tb_name");
		  /*Delete Page when deactivated plugin*/	
			$the_page_title = get_option( "sk_customers_page_title" );
			$the_page_name = get_option( "sk_customers_page_name" );
			$the_page_id = get_option( 'sk_customers_page_id' );
			if( $the_page_id ) {
				wp_delete_post( $the_page_id, true ); // this will trash, not delete
				
			}
			delete_option("sk_customers_page_title");
			delete_option("sk_customers_page_name");
			delete_option("sk_customers_page_id");
}


/** Step 3. */
function sk_customers_options() {
	if ( !current_user_can( 'manage_options' ) )  {
		wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
	}
	
	?>
	<?php if(isset($_GET['action']) && $_GET['action'] == 'edit'){ 
	 global $wpdb;
	  $cust = $wpdb->get_row ( "SELECT * FROM wp_skcustomers where id=".$_GET['id'] );
		 //print_r($cust);
		 //print_r($cust->name);
			 ?>
            <div class="wrap">
             <h1>Edit Customer</h1>
               <?php //sk_show_updateerror_messages(); ?>

        <form id="sk_customers_form" class="sk_upform form" action="" method="POST" enctype="multipart/form-data">
        <fieldset>
            <p>
              <label for="sk_name"><?php _e('Name'); ?></label>
              <input name="sk_name" id="sk_name" class="required" value="<?php echo $cust->name; ?>" type="text">
            </p>
            <p>
                <label for="sk_address"><?php _e('Address'); ?></label>
                <textarea name="sk_address" type="sk_address" id="sk_address" class="required txtarea"><?php echo $cust->address; ?></textarea>
            </p>
            <p>
                <label for="sk_phone"><?php _e('Phone'); ?></label>
                <input name="sk_phone" id="sk_phone" value="<?php echo $cust->phone; ?>" class="required" type="text">
            </p>
            <p>
                <label for="sk_email"><?php _e('Email'); ?></label>
                <input name="sk_email" id="sk_email" value="<?php echo $cust->email; ?>" class="required" type="text">
            </p>
            <p>
                <label for="sk_image"><?php _e('Your Image'); ?></label>
                <img src="<?php echo $cust->image; ?>" width="350" height="210"><br>
                <input name="sk_image" id="sk_image" class="imgup"  type="file" accept='image/*'>
            </p>
            <p>
              <input type="hidden" name="sk_editcustomers_nonce" value="<?php echo wp_create_nonce('sk_customers_nonce'); ?>"/>
             <input type="submit" class="button button-primary" value="<?php _e('Edit Customer'); ?>"/>  
            </p>
        </fieldset>
    </form>
            </div>
   <?php	} else { ?>


	<div class="wrap">
	   <h1>Customers</h1>

	   <table class="wp-list-table widefat fixed striped pages">
	   <tr>
	   	<th>ID</th>
	   	<th>NAME</th>
	   	<th>ADDRESS</th>
	   	<th>PHONE</th>
	   	<th>EMAIL</th>
	   	<th>IMAGE</th>
	   	<th>status</th>
	 
	   </tr>
	  <?php 
	  global $wpdb;
	  $result = $wpdb->get_results ( "SELECT * FROM wp_skcustomers" );
			
			foreach ( $result as $cust )   { ?>
	   <tr>
	    <td><?php echo $cust->id; ?></td>
	   	<td><?php echo $cust->name; ?>
	   		<div class="row-actions"><span class="edit"><a href="<?php
	   		echo $_SERVER["PHP_SELF"];?>?page=sk-customer&amp;id=<?php echo $cust->id; ?>&amp;action=edit" aria-label="Edit “Add Customers”">Edit</a> | </span><span class="trash"><a href="<?php
	   		echo $_SERVER["PHP_SELF"];?>?page=sk-customer&amp;id=<?php echo $cust->id; ?>&amp;action=delete" class="submitdelete" aria-label="Move “Add Customers” to the Trash" onClick="return confirm('Delete This customer?')">Delete</a>  </span></div>
	   	</td>
	   	<td><?php echo $cust->address; ?></td>
	   	<td><?php echo $cust->phone; ?></td>
	    <td><?php echo $cust->email; ?></td>
	   	<td><img src="<?php echo $cust->image; ?>" width="150" height="75"></td>
	   	<td>
	   	<select id="status" name="status" onchange="setStatus(this,<?php echo $cust->id; ?>);">
	   	    <option value="">Select Status</option>
	   		<option value="approve" <?php echo ($cust->status == 'approve') ? 'selected' : '' ; ?>  >Approve</option>
	   		<option value="disapprove" <?php echo  ($cust->status == 'disapprove') ? 'selected' : '' ; ?> >Disapprove</option>
	   	</select>
	   	<div id="cust_status<?php echo $cust->id;?>"></div>
	   	</td>
	   
	   </tr>
	   <?php } ?>
	   </table>
	</div>
	<?php } ?>

	<?php
}    

function sk_approved_customers(){
	?>
	<div class="wrap">
	  


	 
	  <?php 
	  global $wpdb;
	  $result = $wpdb->get_results ( "SELECT * FROM wp_skcustomers where status='approve'" );
			
			foreach ( $result as $cust )   { ?>
			<div class="recrd">
			<div class="border">
			<div class="left">
			
			<div><img src="<?php echo $cust->image; ?>" width="150" height="75"></div>
	   </div>
	    <div class="right">
	   	<div><?php echo $cust->name; ?></div>
		<div><?php echo $cust->address; ?></div>
	   	<div><?php echo $cust->phone; ?></div>
	    <div><?php echo $cust->email; ?></div>
	     </div></div>
	 </div>
	   
	
	   <?php } ?>
	 </div>
	
	<?php
}
add_shortcode('sk_approved_customers_list', 'sk_approved_customers');
  



add_filter('wp_nav_menu_items','add_field');
function add_field($nav){
	$post = get_post($the_page_id); 
    $slug = $post->post_name;
	$postslug = 'add-customers';
    return $nav."<li><a href=".$postslug.">Add Customers</a></li>";
}

if(isset($_POST['cust_status']) && isset($_POST['approveid'])){
	global $wpdb;
	$status     =  $_POST['cust_status'];
	$approveid  =  $_POST['approveid'];
	$customer_data = array(
		'status' => $status
		);
	$tb_name = $wpdb->prefix . 'skcustomers';
    $res = $wpdb->update($tb_name,$customer_data, array( 'id' => $approveid ));
}

function sk_customers_form_fields(){
    ob_start(); ?>
    <h3 class="sk_header"><?php _e('Register New Customer'); ?> </h3>
    <?php sk_show_error_messages();   
    if(isset($_GET['msg']) && $_GET['msg'] == "added" ){
         	  echo "<div style='color:rgba(36, 78, 5, 0.78);font-size: 28px;'>Added Successfully</div>";
         }
         ?>
    <form id="sk_customers_form" class="sk_form" action="" method="POST" enctype="multipart/form-data">
        <fieldset>
            <p>
              <label for="sk_name"><?php _e('Name'); ?></label>
              <input name="sk_name" id="sk_name" class="required" type="text">
            </p>
            <p>
                <label for="sk_address"><?php _e('Address'); ?></label>
                <textarea name="sk_address" type="sk_address" id="sk_address" class="required"></textarea>
            </p>
            <p>
                <label for="sk_phone"><?php _e('Phone'); ?></label>
                <input name="sk_phone" id="sk_phone" class="required" type="text">
            </p>
            <p>
                <label for="sk_email"><?php _e('Email'); ?></label>
                <input name="sk_email" id="sk_email" class="required" type="text">
            </p>
            <p>
                <label for="sk_image"><?php _e('Your Image'); ?></label>
                <input name="sk_image" id="sk_image" class="required" type="file" accept='image/*'>
            </p>
            <p>
              <input type="hidden" name="sk_customers_nonce" value="<?php echo wp_create_nonce('sk_customers_nonce'); ?>"/>
             <input type="submit" value="<?php _e('Add New Customers'); ?>"/>  
            </p>
        </fieldset>
    </form>
   <?php
	return ob_get_clean();
}

add_shortcode('sk_customer_form', 'sk_customers_form_fields');



// add new customer
function sk_add_customer(){
	global $wpdb;
	global $tb_name;
    if(isset($_POST["sk_name"]) && wp_verify_nonce($_POST['sk_customers_nonce'], 'sk_customers_nonce')){
        $name = $_POST['sk_name'];
        $address = $_POST['sk_address'];
        $phone = $_POST['sk_phone'];
        $email = $_POST['sk_email'];
        $image = $_FILES['sk_image']['name'];
        //print_r($image);
        //die();g
        
        if($name == '') {
        	sk_errors()->add('name empty', __('Please enter a username'));
        }
        if(!is_email($email)) {
			//invalid email
			sk_errors()->add('email_invalid', __('Invalid email'));
		}
		if($address == '') {
        	sk_errors()->add('address empty', __('Please enter Address'));
        }
        if($phone == '') {
        	sk_errors()->add('phone empty', __('Please enter phone number'));
        }
        if($image == '') {
        	sk_errors()->add('File empty', __('File should not be empty'));
        }
        $errors = sk_errors()->get_error_messages();

        if(empty($errors)) {

        	$upload_dir = wp_upload_dir();
		    $user_dirname = $upload_dir['basedir'].'/img';
			if ( ! file_exists( $user_dirname ) ) {
			wp_mkdir_p( $user_dirname );
			}
		  	$filename = $_FILES['sk_image']['name'];
		  	$wp_filetype = wp_check_filetype( basename($filename), null );
    	  	$wp_upload_dir = wp_upload_dir();
		 	 // Move the uploaded file into the WordPress uploads directory
    	  	move_uploaded_file( $_FILES['sk_image']['tmp_name'], $user_dirname  . '/' . $filename );
		  	//$attachments = array(WP_CONTENT_DIR.'/uploads/img/'.basename($_FILES['thumbnail']['name']));
	         $path=get_home_url();
			$filename =  $path. '/wp-content/uploads/img/' . $filename;
           // $content=$_POST['content'];
        	$customer_data = array(
                   'name'            => $name,
                   'address'	     => $address,
                   'phone'	     => $phone,
                   'email' 	     => $email,
                   'image' 	     => $filename

        		);
        	$tb_name = $wpdb->prefix . 'skcustomers';
			$res = $wpdb->insert($tb_name,$customer_data);
			if($res){
			$loc =  $_SERVER[REQUEST_URI]."?msg=added";
		 	header("Location:".$loc);
		 	exit;
			//header('location:'.$loc);
		 	//header('Refresh: 5; URL='.$loc);
		 }
           
        }

    }else{
    	$name = $_POST['sk_name'];
        $address = $_POST['sk_address'];
        $phone = $_POST['sk_phone'];
        $email = $_POST['sk_email'];
        $image = $_FILES['sk_image']['name'];
        //print_r($image);
        //die();

        if($name == '') {
        	sk_updateerrors()->add('name empty', __('Please enter a username'));
        }
        if(!is_email($email)) {
			//invalid email
			sk_updateerrors()->add('email_invalid', __('Invalid email'));
		}
		if($address == '') {
        	sk_updateerrors()->add('address empty', __('Please enter Address'));
        }
        if($phone == '') {
        	sk_updateerrors()->add('phone empty', __('Please enter phone number'));
        }
       
        $errors = sk_updateerrors()->get_error_messages();

        if(empty($errors)) {
            $upload_dir = wp_upload_dir();
		    $user_dirname = $upload_dir['basedir'].'/img';
			if ( ! file_exists( $user_dirname ) ) {
			wp_mkdir_p( $user_dirname );
			}
		  	$filename = $_FILES['sk_image']['name'];
		  	$wp_filetype = wp_check_filetype( basename($filename), null );
    	  	$wp_upload_dir = wp_upload_dir();
		 	 // Move the uploaded file into the WordPress uploads directory
    	  	move_uploaded_file( $_FILES['sk_image']['tmp_name'], $user_dirname  . '/' . $filename );
		  	//$attachments = array(WP_CONTENT_DIR.'/uploads/img/'.basename($_FILES['thumbnail']['name']));
	         $path=get_home_url();
			$filename =  $path. '/wp-content/uploads/img/' . $filename;
            if(!empty($image)) { 
        	$customer_data = array(
                   'name'            => $name,
                   'address'	     => $address,
                   'phone'	     => $phone,
                   'email' 	     => $email,
                   'image' 	     => $filename

        		);
            }else{
            	$customer_data = array(
                   'name'            => $name,
                   'address'	     => $address,
                   'phone'	     => $phone,
                   'email' 	     => $email
                  

        		);
            }
           // $content=$_POST['content'];
        	
        	//print_r($customer_data);
            //print_r($tb_name);
            $tb_name = $wpdb->prefix . 'skcustomers';
			$res = $wpdb->update($tb_name,$customer_data, array( 'id' => $_GET['id'] ));
			//print_r($res);
			//die();
			 if($res){
			add_action( 'admin_notices', 'my_admin_notice' );
		 	$loc =  $_SERVER[PHP_SELF]."?page=sk-customer";
		 	//print_r($loc);
		 	//header('location:'.$loc);
		 	//die;
		 	//header('location:'.$loc);
		 	
		 	//header('Refresh: 0; URL='.$loc);
		 	
		 }
           }
    }
}


add_action('init', 'sk_add_customer');

// used for tracking error messages
function sk_errors(){
    static $wp_error; // Will hold global variable safely
    return isset($wp_error) ? $wp_error : ($wp_error = new WP_Error(null, null, null));
}

function sk_updateerrors(){
    static $wp_error; // Will hold global variable safely
    return isset($wp_error) ? $wp_error : ($wp_error = new WP_Error(null, null, null));
}

// displays error messages from form submissions
function sk_show_error_messages() {
	if($codes = sk_errors()->get_error_codes()) {
		echo '<div class="sk_errors">';
		    // Loop error codes and display errors
		   foreach($codes as $code){
		        $message = sk_errors()->get_error_message($code);
		        echo '<span class="error"><strong>' . __('Error') . '</strong>: ' . $message . '</span><br/>';
		    }
		echo '</div>';
	}	
}

function sk_show_updateerror_messages() {
	if($codes = sk_updateerrors()->get_error_codes()) {
		echo '<div class="sk_updateerrors">';
		    // Loop error codes and display errors
		   foreach($codes as $code){
		        $message = sk_updateerrors()->get_error_message($code);
		        echo '<span class="error"><strong>' . __('Error') . '</strong>: ' . $message . '</span><br/>';
		    }
		echo '</div>';
	}	
}

// register our form css
function sk_register_css() {
	wp_register_style('skcustomers', plugin_dir_url( __FILE__ ) . '/css/forms.css');
	 wp_enqueue_style('skcustomers');
	
      wp_register_script('jqueryvalidator', plugin_dir_url( __FILE__ ) . '/js/jquery.validate.min.js',array('jquery'));
	 wp_enqueue_script('jqueryvalidator');

	 wp_register_script('skcustomersscript', plugin_dir_url( __FILE__ ) . '/js/form.js',array('jquery','jqueryvalidator'));
	 wp_enqueue_script('skcustomersscript');
	 ?> 
	<?php
}
add_action('init', 'sk_register_css');

?>
