
jQuery(document).ready(function($) {
	  $( "#sk_customers_form" ).validate({
	  rules: {
	      sk_name: {
	      required: true
	    },
	     sk_address: {
	      required: true
	    },
	    sk_email: {
	      required: true,
	      email: true
	    },
	    sk_phone: {
	      required: true
	    },
	  

	  },

	 messages: {
	sk_name: "Please enter a valid name.",
	sk_email: "Please enter a valid email address.",
	sk_address: "Please use a valid  address.",
	sk_phone: "Phone must be at least 10 characters.",
	
          
   
}
	});
});

function setStatus(sel,id){
	//alert(sel.value);
	 var cust_status = sel.value;
	  //var status = jQuery("#status ").val();
	//alert(cust_status);
	//alert(status);
	
	if(cust_status == "approve"){
     var x = confirm("Do you want to approve");
	}else if(cust_status == "disapprove"){
     var x = confirm("Do you want to disapprove");
	}
	
	if(x){
		 jQuery.post(" ",
    {
        cust_status: cust_status,
        approveid: id
    },
    function(data, status){
       // alert("Data: " + data + "\nStatus: " + status);
       
    jQuery("#cust_status"+id).html("customer  " + cust_status +"d");
    if (cust_status == 'approve') {
       	 jQuery("#cust_status"+id).css('color','#228B22');
       }else{
         jQuery("#cust_status"+id).css('color','#FF0000');
       }
    });

	}
}